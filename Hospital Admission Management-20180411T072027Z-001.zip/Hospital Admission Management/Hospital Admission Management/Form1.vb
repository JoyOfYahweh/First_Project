﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OBJ As New Registration_Form
        If (userbox.Text = "Admin" And passbox.Text = "Pass") Then
            MessageBox.Show("Successfully Login")
        Else
            MessageBox.Show("Login Failed")
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        userbox.Text = ""
        passbox.Clear()
        userbox.Focus()
    End Sub

    Private Sub userbox_TextChanged(sender As Object, e As EventArgs) Handles userbox.TextChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
