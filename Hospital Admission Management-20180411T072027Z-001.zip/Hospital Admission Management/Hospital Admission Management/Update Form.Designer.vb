﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Update_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Update_Form))
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.comboA1 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.comboA2 = New System.Windows.Forms.ComboBox()
        Me.comboA3 = New System.Windows.Forms.ComboBox()
        Me.comboA4 = New System.Windows.Forms.ComboBox()
        Me.comboA5 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(24, 21)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 17)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "Room No."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(54, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(16, 17)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(54, 96)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 17)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(54, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(16, 17)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(54, 172)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(16, 17)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(54, 210)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(16, 17)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "5"
        '
        'comboA1
        '
        Me.comboA1.FormattingEnabled = True
        Me.comboA1.Items.AddRange(New Object() {"Available", "Occupied", "Reserved"})
        Me.comboA1.Location = New System.Drawing.Point(134, 59)
        Me.comboA1.Name = "comboA1"
        Me.comboA1.Size = New System.Drawing.Size(121, 21)
        Me.comboA1.TabIndex = 34
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(158, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "Availability"
        '
        'comboA2
        '
        Me.comboA2.FormattingEnabled = True
        Me.comboA2.Items.AddRange(New Object() {"Available", "Occupied", "Reserved"})
        Me.comboA2.Location = New System.Drawing.Point(134, 96)
        Me.comboA2.Name = "comboA2"
        Me.comboA2.Size = New System.Drawing.Size(121, 21)
        Me.comboA2.TabIndex = 36
        '
        'comboA3
        '
        Me.comboA3.FormattingEnabled = True
        Me.comboA3.Items.AddRange(New Object() {"Available", "Occupied", "Reserved"})
        Me.comboA3.Location = New System.Drawing.Point(134, 134)
        Me.comboA3.Name = "comboA3"
        Me.comboA3.Size = New System.Drawing.Size(121, 21)
        Me.comboA3.TabIndex = 37
        '
        'comboA4
        '
        Me.comboA4.FormattingEnabled = True
        Me.comboA4.Items.AddRange(New Object() {"Available", "Occupied", "Reserved"})
        Me.comboA4.Location = New System.Drawing.Point(134, 172)
        Me.comboA4.Name = "comboA4"
        Me.comboA4.Size = New System.Drawing.Size(121, 21)
        Me.comboA4.TabIndex = 38
        '
        'comboA5
        '
        Me.comboA5.FormattingEnabled = True
        Me.comboA5.Items.AddRange(New Object() {"Available", "Occupied", "Reserved"})
        Me.comboA5.Location = New System.Drawing.Point(134, 210)
        Me.comboA5.Name = "comboA5"
        Me.comboA5.Size = New System.Drawing.Size(121, 21)
        Me.comboA5.TabIndex = 39
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(190, 247)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(65, 23)
        Me.Button1.TabIndex = 40
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(190, 276)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(65, 23)
        Me.Button3.TabIndex = 42
        Me.Button3.Text = "Back"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Update_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(281, 343)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.comboA5)
        Me.Controls.Add(Me.comboA4)
        Me.Controls.Add(Me.comboA3)
        Me.Controls.Add(Me.comboA2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.comboA1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label9)
        Me.Name = "Update_Form"
        Me.Text = "Update_Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents comboA1 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents comboA2 As ComboBox
    Friend WithEvents comboA3 As ComboBox
    Friend WithEvents comboA4 As ComboBox
    Friend WithEvents comboA5 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button3 As Button
End Class
