﻿Public Class Patient_Information
    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If btnEdit.Text = String.Empty Then
            MsgBox("Search bar is empty", MsgBoxStyle.Information)
        Else
            btnEdit.Enabled = True

        End If
    End Sub

    Private Sub Patient_Information_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class