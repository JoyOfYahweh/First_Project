﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Registration_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Registration_Form))
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.lblmessage = New System.Windows.Forms.Label()
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblage = New System.Windows.Forms.Label()
        Me.lblgender = New System.Windows.Forms.Label()
        Me.lbladdress = New System.Windows.Forms.Label()
        Me.lblcontact = New System.Windows.Forms.Label()
        Me.textName = New System.Windows.Forms.TextBox()
        Me.textAge = New System.Windows.Forms.TextBox()
        Me.textGender = New System.Windows.Forms.TextBox()
        Me.textAddress = New System.Windows.Forms.TextBox()
        Me.textContact = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.lblmessage2 = New System.Windows.Forms.Label()
        Me.lbltype = New System.Windows.Forms.Label()
        Me.comboType = New System.Windows.Forms.ComboBox()
        Me.lblno = New System.Windows.Forms.Label()
        Me.combonumber = New System.Windows.Forms.ComboBox()
        Me.lbldoc = New System.Windows.Forms.Label()
        Me.textDocName = New System.Windows.Forms.TextBox()
        Me.lblprice = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.lblin = New System.Windows.Forms.Label()
        Me.lblout = New System.Windows.Forms.Label()
        Me.dtpDateSelection = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.comboprice = New System.Windows.Forms.ComboBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TextBox1.Location = New System.Drawing.Point(12, 12)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(524, 188)
        Me.TextBox1.TabIndex = 0
        '
        'lblmessage
        '
        Me.lblmessage.AutoSize = True
        Me.lblmessage.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmessage.Location = New System.Drawing.Point(175, 21)
        Me.lblmessage.Name = "lblmessage"
        Me.lblmessage.Size = New System.Drawing.Size(129, 17)
        Me.lblmessage.TabIndex = 1
        Me.lblmessage.Text = "Patient Information"
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblname.Location = New System.Drawing.Point(23, 51)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(42, 16)
        Me.lblname.TabIndex = 2
        Me.lblname.Text = "Name"
        '
        'lblage
        '
        Me.lblage.AutoSize = True
        Me.lblage.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblage.Location = New System.Drawing.Point(23, 77)
        Me.lblage.Name = "lblage"
        Me.lblage.Size = New System.Drawing.Size(31, 16)
        Me.lblage.TabIndex = 3
        Me.lblage.Text = "Age"
        '
        'lblgender
        '
        Me.lblgender.AutoSize = True
        Me.lblgender.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgender.Location = New System.Drawing.Point(23, 105)
        Me.lblgender.Name = "lblgender"
        Me.lblgender.Size = New System.Drawing.Size(50, 16)
        Me.lblgender.TabIndex = 4
        Me.lblgender.Text = "Gender"
        '
        'lbladdress
        '
        Me.lbladdress.AutoSize = True
        Me.lbladdress.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladdress.Location = New System.Drawing.Point(23, 132)
        Me.lbladdress.Name = "lbladdress"
        Me.lbladdress.Size = New System.Drawing.Size(56, 16)
        Me.lbladdress.TabIndex = 5
        Me.lbladdress.Text = "Address"
        '
        'lblcontact
        '
        Me.lblcontact.AutoSize = True
        Me.lblcontact.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcontact.Location = New System.Drawing.Point(23, 160)
        Me.lblcontact.Name = "lblcontact"
        Me.lblcontact.Size = New System.Drawing.Size(77, 16)
        Me.lblcontact.TabIndex = 6
        Me.lblcontact.Text = "Contact No."
        '
        'textName
        '
        Me.textName.Location = New System.Drawing.Point(100, 50)
        Me.textName.Name = "textName"
        Me.textName.Size = New System.Drawing.Size(130, 20)
        Me.textName.TabIndex = 7
        '
        'textAge
        '
        Me.textAge.Location = New System.Drawing.Point(100, 76)
        Me.textAge.Name = "textAge"
        Me.textAge.Size = New System.Drawing.Size(130, 20)
        Me.textAge.TabIndex = 8
        '
        'textGender
        '
        Me.textGender.Location = New System.Drawing.Point(100, 104)
        Me.textGender.Name = "textGender"
        Me.textGender.Size = New System.Drawing.Size(130, 20)
        Me.textGender.TabIndex = 9
        '
        'textAddress
        '
        Me.textAddress.Location = New System.Drawing.Point(100, 136)
        Me.textAddress.Name = "textAddress"
        Me.textAddress.Size = New System.Drawing.Size(130, 20)
        Me.textAddress.TabIndex = 10
        '
        'textContact
        '
        Me.textContact.Location = New System.Drawing.Point(100, 162)
        Me.textContact.Name = "textContact"
        Me.textContact.Size = New System.Drawing.Size(130, 20)
        Me.textContact.TabIndex = 11
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.TextBox7.Location = New System.Drawing.Point(86, 213)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(235, 142)
        Me.TextBox7.TabIndex = 12
        '
        'lblmessage2
        '
        Me.lblmessage2.AutoSize = True
        Me.lblmessage2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmessage2.Location = New System.Drawing.Point(146, 224)
        Me.lblmessage2.Name = "lblmessage2"
        Me.lblmessage2.Size = New System.Drawing.Size(124, 17)
        Me.lblmessage2.TabIndex = 13
        Me.lblmessage2.Text = "Room Information"
        '
        'lbltype
        '
        Me.lbltype.AutoSize = True
        Me.lbltype.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltype.Location = New System.Drawing.Point(94, 255)
        Me.lbltype.Name = "lbltype"
        Me.lbltype.Size = New System.Drawing.Size(80, 16)
        Me.lbltype.TabIndex = 14
        Me.lbltype.Text = "Room Type"
        '
        'comboType
        '
        Me.comboType.FormattingEnabled = True
        Me.comboType.Items.AddRange(New Object() {"Normal Room", "Semi-Private Room", "VIP Room"})
        Me.comboType.Location = New System.Drawing.Point(183, 255)
        Me.comboType.Name = "comboType"
        Me.comboType.Size = New System.Drawing.Size(121, 21)
        Me.comboType.TabIndex = 15
        Me.comboType.Text = "Normal Room"
        '
        'lblno
        '
        Me.lblno.AutoSize = True
        Me.lblno.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblno.Location = New System.Drawing.Point(97, 284)
        Me.lblno.Name = "lblno"
        Me.lblno.Size = New System.Drawing.Size(69, 16)
        Me.lblno.TabIndex = 16
        Me.lblno.Text = "Room No."
        '
        'combonumber
        '
        Me.combonumber.FormattingEnabled = True
        Me.combonumber.Items.AddRange(New Object() {"Room 1", "Room 2", "Room 3", "Room 4", "Room 5"})
        Me.combonumber.Location = New System.Drawing.Point(183, 283)
        Me.combonumber.Name = "combonumber"
        Me.combonumber.Size = New System.Drawing.Size(121, 21)
        Me.combonumber.TabIndex = 17
        Me.combonumber.Text = "Room 1"
        '
        'lbldoc
        '
        Me.lbldoc.AutoSize = True
        Me.lbldoc.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldoc.Location = New System.Drawing.Point(237, 54)
        Me.lbldoc.Name = "lbldoc"
        Me.lbldoc.Size = New System.Drawing.Size(93, 16)
        Me.lbldoc.TabIndex = 18
        Me.lbldoc.Text = "Doctor's Name"
        '
        'textDocName
        '
        Me.textDocName.Location = New System.Drawing.Point(336, 54)
        Me.textDocName.Name = "textDocName"
        Me.textDocName.Size = New System.Drawing.Size(181, 20)
        Me.textDocName.TabIndex = 19
        '
        'lblprice
        '
        Me.lblprice.AutoSize = True
        Me.lblprice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprice.Location = New System.Drawing.Point(97, 311)
        Me.lblprice.Name = "lblprice"
        Me.lblprice.Size = New System.Drawing.Size(39, 16)
        Me.lblprice.TabIndex = 20
        Me.lblprice.Text = "Price"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(5, 224)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "Register"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(5, 282)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 23
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(5, 253)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 25
        Me.Button4.Text = "Save"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'lblin
        '
        Me.lblin.AutoSize = True
        Me.lblin.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblin.Location = New System.Drawing.Point(237, 84)
        Me.lblin.Name = "lblin"
        Me.lblin.Size = New System.Drawing.Size(59, 16)
        Me.lblin.TabIndex = 26
        Me.lblin.Text = "Check in"
        '
        'lblout
        '
        Me.lblout.AutoSize = True
        Me.lblout.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblout.Location = New System.Drawing.Point(237, 110)
        Me.lblout.Name = "lblout"
        Me.lblout.Size = New System.Drawing.Size(67, 16)
        Me.lblout.TabIndex = 45
        Me.lblout.Text = "Check out"
        '
        'dtpDateSelection
        '
        Me.dtpDateSelection.Checked = False
        Me.dtpDateSelection.CustomFormat = "mm/dd/yy"
        Me.dtpDateSelection.Location = New System.Drawing.Point(336, 80)
        Me.dtpDateSelection.Name = "dtpDateSelection"
        Me.dtpDateSelection.Size = New System.Drawing.Size(181, 20)
        Me.dtpDateSelection.TabIndex = 47
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(336, 106)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(181, 20)
        Me.DateTimePicker2.TabIndex = 48
        '
        'comboprice
        '
        Me.comboprice.FormattingEnabled = True
        Me.comboprice.Items.AddRange(New Object() {"800", "1500", "3500"})
        Me.comboprice.Location = New System.Drawing.Point(183, 311)
        Me.comboprice.Name = "comboprice"
        Me.comboprice.Size = New System.Drawing.Size(121, 21)
        Me.comboprice.TabIndex = 49
        Me.comboprice.Text = "800"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(5, 311)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 50
        Me.Button5.Text = "Next"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Registration_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(548, 371)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.comboprice)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.dtpDateSelection)
        Me.Controls.Add(Me.lblout)
        Me.Controls.Add(Me.lblin)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lblprice)
        Me.Controls.Add(Me.textDocName)
        Me.Controls.Add(Me.lbldoc)
        Me.Controls.Add(Me.combonumber)
        Me.Controls.Add(Me.lblno)
        Me.Controls.Add(Me.comboType)
        Me.Controls.Add(Me.lbltype)
        Me.Controls.Add(Me.lblmessage2)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.textContact)
        Me.Controls.Add(Me.textAddress)
        Me.Controls.Add(Me.textGender)
        Me.Controls.Add(Me.textAge)
        Me.Controls.Add(Me.textName)
        Me.Controls.Add(Me.lblcontact)
        Me.Controls.Add(Me.lbladdress)
        Me.Controls.Add(Me.lblgender)
        Me.Controls.Add(Me.lblage)
        Me.Controls.Add(Me.lblname)
        Me.Controls.Add(Me.lblmessage)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Registration_Form"
        Me.Text = "Registration_Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lblmessage As Label
    Friend WithEvents lblname As Label
    Friend WithEvents lblage As Label
    Friend WithEvents lblgender As Label
    Friend WithEvents lbladdress As Label
    Friend WithEvents lblcontact As Label
    Friend WithEvents textName As TextBox
    Friend WithEvents textAge As TextBox
    Friend WithEvents textGender As TextBox
    Friend WithEvents textAddress As TextBox
    Friend WithEvents textContact As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents lblmessage2 As Label
    Friend WithEvents lbltype As Label
    Friend WithEvents comboType As ComboBox
    Friend WithEvents lblno As Label
    Friend WithEvents combonumber As ComboBox
    Friend WithEvents lbldoc As Label
    Friend WithEvents textDocName As TextBox
    Friend WithEvents lblprice As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents lblin As Label
    Friend WithEvents lblout As Label
    Friend WithEvents dtpDateSelection As DateTimePicker
    Friend WithEvents DateTimePicker2 As DateTimePicker
    Friend WithEvents comboprice As ComboBox
    Friend WithEvents Button5 As Button
End Class
