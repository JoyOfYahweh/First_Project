﻿Public Class Update_Form
    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboA4.SelectedIndexChanged

    End Sub
End Class