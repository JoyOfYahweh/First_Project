﻿Public Class Registration_Form

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim msg As String
        msg = "Name is :" & textName.Text
        msg = msg & ",Age is :" & textAge.Text
        msg = msg & ",Gender is :" & textGender.Text
        msg = msg & ",Address is :" & textAddress.Text
        msg = msg & ",Contact Number is :" & textContact.Text
        msg = msg & ",Doctor Name is :" & textDocName.Text
        msg = msg & ",Room Type is :" & comboType.SelectedItem.ToString()
        msg = msg & ",Room Number is :" & combonumber.SelectedItem.ToString()
        msg = msg & ",Price is :" & comboprice.SelectedItem.ToString()
    End Sub

    Private Sub Registration_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpDateSelection.Value = Now
    End Sub

    Private Sub dtpDateSelection_ValueChanged(sender As Object, e As EventArgs) Handles dtpDateSelection.ValueChanged
        MessageBox.Show(dtpDateSelection.Value)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        textName.Text = ""
        textAge.Text = ""
        textGender.Text = ""
        textAddress.Text = ""
        textContact.Text = ""
        textDocName.Text = ""
        comboType.Text = ""
        combonumber.Text = ""
        comboprice.Text = ""
        textName.Clear()
        textAge.Clear()
        textGender.Clear()
        textAddress.Clear()
        textContact.Clear()
        textDocName.Clear()
        textName.Focus()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

    End Sub

    Private Sub comboType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboType.SelectedIndexChanged

    End Sub

    Private Sub textName_TextChanged(sender As Object, e As EventArgs) Handles textName.TextChanged

    End Sub
End Class